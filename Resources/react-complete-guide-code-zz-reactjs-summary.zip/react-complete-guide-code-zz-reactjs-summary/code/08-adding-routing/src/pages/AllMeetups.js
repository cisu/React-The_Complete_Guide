function AllMeetupsPage() {
  return <div>All Meetups Page</div>;
}

export default AllMeetupsPage;
